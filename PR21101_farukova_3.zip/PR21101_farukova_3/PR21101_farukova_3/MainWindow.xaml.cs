﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR21101_farukova_3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получаем значения из текстовых полей
                if (int.TryParse(NInput.Text, out int n) &&
                    int.TryParse(minInput.Text, out int min) &&
                    int.TryParse(maxInput.Text, out int max))
                {
                    // Создаем массив размера N
                    int[] array = new int[n];

                    // Генерируем случайные числа в заданном диапазоне и заполняем ими массив
                    Random rnd = new Random();
                    for (int i = 0; i < n; i++)
                    {
                        array[i] = rnd.Next(min, max + 1);
                    }

                    // Сортируем массив так, чтобы в начале были четные элементы, а в конце - нечетные
                    Array.Sort(array, (x, y) => (x % 2).CompareTo(y % 2));

                    // Выводим полученный массив на экран
                    resultLabel.Content = "Отсортированный массив: " + string.Join(", ", array);
                }
                //Ошибка при вводе типа данных
                else
                {
                    resultLabel.Content = "Неверный ввод!";
                }
            }
            //Ошибка при вводе логики
            catch (Exception ex)
            {
                resultLabel.Content = "Ошибка: " + ex.Message;
            }
        }
    }
}
